public class PersonTwo {
  
  public String name = "Jonathan";
  public String job = "Ice Cream Taster";

  public void display(){
    System.out.println("My name is " + name + ", I am a " + job);
  }
} // end of class
