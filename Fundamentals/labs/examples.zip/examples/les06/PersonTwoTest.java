class PersonTwoTest {
   
  public static void main (String args[]) {
 
    PersonTwo myPerson = new PersonTwo();
  
    myPerson.display();

  } 
}
