public class IfElseDateTest {

   public static void main(String args[]) {
     
    IfElseDate myIfElse = new IfElseDate();

    myIfElse.calculateNumDays();
     
   }
}
