public class PrivateElevator1 {

   public boolean doorOpen=false;
   public int currentFloor = 1;
   private int weight =0;
   
   private final int CAPACITY=1000;
   private final int TOP_FLOOR = 5;
   private final int BOTTOM_FLOOR = 1;
}
