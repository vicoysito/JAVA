public class ClothingTest {
   
  public static void main (String args[]) {
 
  Shirt myShirt = new Shirt();
  
  myShirt.displayShirtInformation();
  } 
}
