public class DateTwoTest {

  public static void main(String args[]) {
     DateTwo date = new DateTwo();
     //date.day = 28;
     //date.month = 07;
     //date.year = 2011;
    
  }// end main
    
} // end class

