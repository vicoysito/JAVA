/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */

public class MonthTest {

    public static void main(String args[]) {
        
        /**
         * @param args the command line arguments
         */
        Month myMonth = new Month();
        myMonth.displayMonth();

    }
}
