public class CustomerTest {
   
  public static void main (String args[]) {
 
  Customer myCustomer = new Customer();
  
  myCustomer.displayCustomerInfo();

  } 
}
