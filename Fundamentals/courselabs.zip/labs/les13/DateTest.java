
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Administrator
 */
public class DateTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DateManipulator dm = new DateManipulator();
        // substitute your own date using format: MM/dd/yyyy -  Example "08/22/2011")
        dm.parseDate("");
    }
}
