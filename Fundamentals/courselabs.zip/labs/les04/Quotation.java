public class Quotation {

  public String quote = "Welcome to Oracle, the new home of Java!";
    
  public void display() {

        // display the member variable here
  }
}
