package duke.item;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author kennys
 */
public interface Returnable {
    public String doReturn();

}
