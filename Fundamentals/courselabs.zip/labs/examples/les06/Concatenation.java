public class Concatenation {
       public static void main (String args[]) {
    String greet = " HOW ".trim();
    String lc = (greet + "DY").toLowerCase();
   System.out.println(greet);
   System.out.println(lc);

   System.out.println("Hello World".substring(6));

    }
}
