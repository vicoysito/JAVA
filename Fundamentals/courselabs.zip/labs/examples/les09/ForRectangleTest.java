public class ForRectangleTest {

   public static void main(String args[]) {
     
    ForRectangle myForRectangle = new ForRectangle();

    myForRectangle.displayRectangle();
     
   }
}
